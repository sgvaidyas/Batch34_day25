﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Batch34_day25
{
    class Lazyloadingex
    {
        static void Main(string[] args)
        {
            ProjLocationModel db = new ProjLocationModel();

            foreach(City c in db.Cities)
            {
                Console.WriteLine("______________________________________-");
                Console.WriteLine("{0},{1}",c.CityId,c.Cityname);
                Console.WriteLine("______________________________________-");
                foreach(DeptLoc d in c.DeptLocs)
                {
                    Console.WriteLine("{0},{1}",d.AreaName,d.AreaId);
                }
            }
        }
    }
}
