﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Batch34_day25
{
    class Program
    {
        static void Main(string[] args)
        {
            ProjLocationModel db = new ProjLocationModel();
            City c = new City();
            c.CityId = 555;
            c.Cityname = "Bombay";
            db.Cities.Add(c);
            db.SaveChanges();

            foreach(City city in db.DISPLAYCITIES())
            {
                Console.WriteLine("{0} = {1}",city.CityId,city.Cityname);
            }

            /* deletion */

        }
    }
}
