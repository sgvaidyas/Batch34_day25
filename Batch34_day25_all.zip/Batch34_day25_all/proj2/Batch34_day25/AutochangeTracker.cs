﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Batch34_day25
{
    class AutochangeTracker
    {
        static void Main(string[] args)
        {
            ProjLocationModel db = new ProjLocationModel();

            City c = new City() { CityId = 666, Cityname = "Vishakapattanam" };
            db.Cities.Add(c);
            City c1 = new City() { CityId = 777, Cityname = "Kolkatta" };
            db.Cities.Add(c1);
            
            City c3 = db.Cities.Find(222);
            if(c3!=null)
            {
                c3.Cityname = "Delhi";
            }
            c3 = db.Cities.Find(555);
            if (c3 != null)
            {
                db.Cities.Remove(c3);
            }


            foreach (var tracker in db.ChangeTracker.Entries<City>())
            {
                Console.WriteLine(tracker.State);
            }
        }
    }
}
