﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Batch34_day25
{
    class DeleteUpdate
    {
        static void Main(string[] args)
        {
            ProjLocationModel db = new ProjLocationModel();

            Console.WriteLine("Enter id");
            int id = int.Parse(Console.ReadLine());

            City c = db.Cities.Find(id);
            if (c == null)
                Console.WriteLine("Id doesnt exist");
            else
            {
                Console.WriteLine("Deleting");
                db.Cities.Remove(c);
                db.SaveChanges();

                foreach (City city in db.DISPLAYCITIES())
                {
                    Console.WriteLine("{0} = {1}", city.CityId, city.Cityname);
                }
            }


            Console.WriteLine("UPDATING\n\n Enter id");
            id = int.Parse(Console.ReadLine());
            c = db.Cities.Find(id);
            if (c == null)
                Console.WriteLine("Id doesnt exist");
            else
            {
                Console.WriteLine("Updating");
                Console.WriteLine("enter the city name");
                string cname = Console.ReadLine();
                c.Cityname = cname;
                db.SaveChanges();

                foreach (City city in db.DISPLAYCITIES())
                {
                    Console.WriteLine("{0} = {1}", city.CityId, city.Cityname);
                }
            }
        }
    }
}
