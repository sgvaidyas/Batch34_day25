﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Batch34_day25
{
    class eagerloadingex
    {
        static void Main(string[] args)
        {
            ProjLocationModel db = new ProjLocationModel();
            foreach(City c in db.Cities.Include("DeptLocs"))
            {
                Console.WriteLine("_________________________________________");
                Console.WriteLine("{0} \t {1} \t",c.CityId,c.Cityname);
                Console.WriteLine("_________________________________________");
                foreach(DeptLoc d in c.DeptLocs)
                {
                    Console.WriteLine("{0} \t {1} \t", d.AreaId,d.AreaName);
                }

            }
        }
    }
}
