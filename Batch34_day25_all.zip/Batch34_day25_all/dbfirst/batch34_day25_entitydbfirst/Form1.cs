﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace batch34_day25_entitydbfirst
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnadd_Click(object sender, EventArgs e)
        {
            City c = new City();

            c.CityId = int.Parse(txtcityid.Text);
            c.Cityname = txtcityname.Text;

            MyModel db = new MyModel();
            try
            {
                db.Cities.Add(c);
                db.SaveChanges();
                MessageBox.Show("City got added");
                txtcityid.Text = "";
                txtcityname.Text = "";
            }
            catch(Exception ob)
            {
                MessageBox.Show(ob.Message);
            }
        }
    }
}
